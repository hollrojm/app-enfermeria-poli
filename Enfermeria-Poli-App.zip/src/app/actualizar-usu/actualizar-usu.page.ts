import { Component, OnInit } from '@angular/core';




@Component({
  selector: 'app-actualizar-usu',
  templateUrl: './actualizar-usu.page.html',
  styleUrls: ['./actualizar-usu.page.scss'],
})
export class ActualizarUsuPage implements OnInit {

  constructor(
  ) { }

  ngOnInit() {
  }

}
