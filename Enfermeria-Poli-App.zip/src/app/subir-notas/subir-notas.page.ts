import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subir-notas',
  templateUrl: './subir-notas.page.html',
  styleUrls: ['./subir-notas.page.scss'],
})
export class SubirNotasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
