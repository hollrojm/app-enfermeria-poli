import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mis-videos',
  templateUrl: './mis-videos.page.html',
  styleUrls: ['./mis-videos.page.scss'],
})
export class MisVideosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
