import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-olvido-pass',
  templateUrl: './olvido-pass.page.html',
  styleUrls: ['./olvido-pass.page.scss'],
})
export class OlvidoPassPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
