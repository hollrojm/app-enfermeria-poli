import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subir-videos',
  templateUrl: './subir-videos.page.html',
  styleUrls: ['./subir-videos.page.scss'],
})
export class SubirVideosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
