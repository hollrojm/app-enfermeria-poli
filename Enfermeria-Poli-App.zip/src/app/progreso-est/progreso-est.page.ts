import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progreso-est',
  templateUrl: './progreso-est.page.html',
  styleUrls: ['./progreso-est.page.scss'],
})
export class ProgresoEstPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
