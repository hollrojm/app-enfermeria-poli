import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simulador-clases',
  templateUrl: './simulador-clases.page.html',
  styleUrls: ['./simulador-clases.page.scss'],
})
export class SimuladorClasesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
