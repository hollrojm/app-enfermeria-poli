import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ver-notas',
  templateUrl: './ver-notas.page.html',
  styleUrls: ['./ver-notas.page.scss'],
})
export class VerNotasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
