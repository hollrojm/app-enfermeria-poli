
import { Injectable } from '@angular/core';
import {MsalService} from '@azure/msal-angular'
import { MsalModule, MsalInterceptor } from "@azure/msal-angular";
/* import { Client } from '@microsoft/microsoft-graph-client'; */

import { from } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AzureService {
  

  constructor(

  ) {
    
   }

  
}
